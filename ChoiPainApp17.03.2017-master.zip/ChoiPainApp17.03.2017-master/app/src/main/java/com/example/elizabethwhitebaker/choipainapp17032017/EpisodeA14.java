package com.example.elizabethwhitebaker.choipainapp17032017;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class EpisodeA14 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_episode_a14);

        Button pMed = (Button)findViewById(R.id.button8E14);
        Button npMed = (Button)findViewById(R.id.button9E14);

        pMed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EpisodeA1.TreatApproach = "Pain Medication";

                EpisodeA1.CollectiveData = "1. "+EpisodeA1.PainLevel + "\n"+ "2. "+EpisodeA1.TypeOfPain + "\n"+"3. "+ EpisodeA1.PainId  + "\n"+"4. "+ EpisodeA1.PainRel + "\n"+"5. "+ EpisodeA1.PainUpdate + "\n"+"6. "+ EpisodeA1.PainFeelLike + "\n"+"7. "+ EpisodeA1.PainStart + "\n"+"8. "+ EpisodeA1.PainLastHour + "\n"+"9. "+ EpisodeA1.PainLastMin + "\n"+"10. "+ EpisodeA1.PainChanges  + "\n"+"11. "+ EpisodeA1.PainBOW + "\n"+"12. "+ EpisodeA1.PainDON + "\n"+"13. "+ EpisodeA1.PainSymptoms + "\n"+"14. "+ EpisodeA1.PainDailyAct + "\n"+"15. "+ EpisodeA1.PainManageBT  + "\n"+"16. "+ EpisodeA1.PrefAltTher + "\n"+"17. "+ EpisodeA1.BodyBack+ "\n"+"18. "+ EpisodeA1.BodyFront + "\n"+"19. "+ EpisodeA1.TreatApproach ;




                Intent intent = new Intent(EpisodeA14.this, EpisodeA15.class);
                startActivity(intent);




            }
        });
        npMed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EpisodeA1.TreatApproach = "Non Medication Approach";

                EpisodeA1.CollectiveData = "1. "+EpisodeA1.PainLevel + "\n"+ "2. "+EpisodeA1.TypeOfPain + "\n"+"3. "+ EpisodeA1.PainId  + "\n"+"4. "+ EpisodeA1.PainRel + "\n"+"5. "+ EpisodeA1.PainUpdate + "\n"+"6. "+ EpisodeA1.PainFeelLike + "\n"+"7. "+ EpisodeA1.PainStart + "\n"+"8. "+ EpisodeA1.PainLastHour + "\n"+"9. "+ EpisodeA1.PainLastMin + "\n"+"10. "+ EpisodeA1.PainChanges  + "\n"+"11. "+ EpisodeA1.PainBOW + "\n"+"12. "+ EpisodeA1.PainDON + "\n"+"13. "+ EpisodeA1.PainSymptoms + "\n"+"14. "+ EpisodeA1.PainDailyAct + "\n"+"15. "+ EpisodeA1.PainManageBT  + "\n"+"16. "+ EpisodeA1.PrefAltTher + "\n"+"17. "+ EpisodeA1.BodyBack+ "\n"+"18. "+ EpisodeA1.BodyFront+ "\n"+"19. "+ EpisodeA1.TreatApproach;

                Intent intent = new Intent(EpisodeA14.this, EpisodeA15.class);
                startActivity(intent);
            }
        });
    }
}
