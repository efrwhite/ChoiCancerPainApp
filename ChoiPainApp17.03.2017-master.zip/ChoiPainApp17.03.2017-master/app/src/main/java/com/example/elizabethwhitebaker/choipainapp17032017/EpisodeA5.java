package com.example.elizabethwhitebaker.choipainapp17032017;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;

public class EpisodeA5 extends AppCompatActivity {
    Spinner sp1;
    Spinner sp2;
    Spinner sp3;
    Spinner sp4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_episode_a5);
        sp1 = (Spinner)findViewById(R.id.spinner4A5);
        sp2 = (Spinner)findViewById(R.id.spinner5A5);
        sp3 = (Spinner)findViewById(R.id.spinner6A5);
        sp4 = (Spinner)findViewById(R.id.spinner7A5);


        Button next = (Button)findViewById(R.id.nextButtonE5);
        Button prev = (Button)findViewById(R.id.prevButtonE5);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EpisodeA1.PainFeelLike = sp1.getSelectedItem().toString();
                EpisodeA1.PainStart = sp2.getSelectedItem().toString();
                EpisodeA1.PainLastHour = sp3.getSelectedItem().toString();
                EpisodeA1.PainLastMin = sp4.getSelectedItem().toString();





                Intent intent = new Intent(EpisodeA5.this, EpisodeA6.class);
                startActivity(intent);
            }
        });
        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EpisodeA5.this, EpisodeA2.class);
                startActivity(intent);
            }
        });


    }
}
