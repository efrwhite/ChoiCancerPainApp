package com.example.elizabethwhitebaker.choipainapp17032017;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class EpisodeA15 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_episode_a15);
        TextView test = (TextView)findViewById(R.id.textView41E15);
        test.setText(EpisodeA1.CollectiveData);
    }
}
